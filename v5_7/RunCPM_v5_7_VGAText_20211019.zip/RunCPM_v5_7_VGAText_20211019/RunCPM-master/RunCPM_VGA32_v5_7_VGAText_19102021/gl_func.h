static void _gl_sd_active() {
                            // =========================================================================================
                            // Activate SPI & SDCard via SDFat-Library
                            // =========================================================================================
                            #if defined board_esp32
                            SPI.begin(SPIINIT);
                            #endif
                            SD.begin(SDINIT);
                            }

                            
