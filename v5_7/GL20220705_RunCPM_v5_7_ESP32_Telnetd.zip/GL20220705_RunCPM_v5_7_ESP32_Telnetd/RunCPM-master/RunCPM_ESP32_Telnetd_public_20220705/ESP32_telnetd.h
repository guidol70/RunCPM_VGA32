/* 
  
  ESP32-telnetd - Telnet Server for ESP32 and clones

  Jan 6, 2019
  
  Mark Bramwell, London, Canada
  http://www.foxhollow.ca
  
*/

// --------------------------------------------------------
// These are the wifi parameters from your router
// --------------------------------------------------------
char wifi_ssid[] =  "Your_SSID";         //  your network SSID (name) 
char wifi_pass[] =  "Your_WiFi_Password";  // your WiFi network password

// If use_static_ip is defined, you must specify IP info (STATIC IP)
#define use_static_ip

// This defines the TELNET port (usually 23)
#define telnetPort 23

// Do you want the ESP32 to display known WiFi networks at startup?
#define want_wifi_scan 0

// add support for the Wifi module
#include <WiFi.h>

// what TCP Port to listen on?  Usually 23
WiFiServer server(telnetPort);

// We allow 2 inbound connections
// 1st connection is interactive, 
// 2nd session is only used to say the 1st is busy then disconnects
WiFiClient serverClient[2];

// If you have requested a STATIC IP for your ESP32
#ifdef use_static_ip
IPAddress local_IP(192, 168, 6, 80);
IPAddress gateway(192, 168, 6, 1);
IPAddress subnet(255, 255, 255, 0);
#endif

// these are sent at connect time to configure the remote client to full duplex
String telnetOption1 = String("\xff\xfe\x22");
String telnetOption2 = String("\xff\xfb\x01");
String telnetOption3 = String("\xff\xfb\x03");

// --------------------------------------------------------
// read any bytes that might be in our network receive 
// buffer. If data was found, read it, wait 100ms, try
// again. repeat until empty.
//
// This is required due to the twitchy nature of ESP chip
// and its memory handling
// --------------------------------------------------------
void wifi_clearBuffer() {
  byte junkData;
  
  while (serverClient[0].available() > 0) {
    while (serverClient[0].available() > 0) junkData = serverClient[0].read();
    delay(100); }
  }


  
// --------------------------------------------------------
// if we are servicing a client and another tries to
// connect, send a busy message.
// --------------------------------------------------------
void wifi_checkBusy() {

 // hmm, if the remote has disconnected, we should
 // restart everything and wait for a new session
 if (serverClient[0].connected() == 0) ESP.restart(); 
 
 // do we have a connect request?
 if (server.hasClient()) {

  // if we are already serving a connection,
  // accept the connection, display a message, disconnect
  if (serverClient[0].connected() == 1) {
     //if (debugMode == 1) Serial.println("*** 2nd Inbound WiFi-IP connection attempted");
     serverClient[1] = server.available(); 
     serverClient[1].write(CCPHEAD);
     serverClient[1].write("\r\n*** System is busy - Try again later\r\n\r\n");
     serverClient[1].stop(); }
 }
}



// --------------------------------------------------------
//  read keyboard data from network terminal
// --------------------------------------------------------
int wifi_getch(){
  //Serial.print("!");  
  if (serverClient[0].available()) return serverClient[0].read(); 
  return 0;
  }


// --------------------------------------------------------
// return status of inbound network stack
// do we have data waiting to be read?
// --------------------------------------------------------
int wifi_kbhit() {
  wifi_checkBusy();
  if (serverClient[0].available()) return 1; 
  return 0; 
}
  

// --------------------------------------------------------
// scan and display all heard WiFi Networks
// --------------------------------------------------------
void WiFiScan() {

  Serial.print("Scanning WiFi: ");
  int n = WiFi.scanNetworks();

  if (n == 0) {
    Serial.println("*** No networks found"); }
  else
  {
    Serial.print(n);
    Serial.println(" WiFi Networks found\r\n");
    for (int i = 0; i < n; ++i)
    {
      // Print SSID and RSSI for each network found
      Serial.print(i + 1);
      Serial.print(": ");
      Serial.print(WiFi.SSID(i));
      Serial.print(" (");
      Serial.print(WiFi.RSSI(i));
      Serial.print(")\r\n");
      delay(10);
    }
  }
  Serial.println(""); 
} // end of WiFiScan()



// --------------------------------------------------------
// Disconnect any connected telnet sessions
// we must delay to allow time for the disconnect packet to be sent
// --------------------------------------------------------
void wifi_disconnect_sessions() {
 serverClient[0].stop();        
 serverClient[1].stop();   
 delay(2000);
 }



// --------------------------------------------------------
// sends a characters to remote wifi user
// --------------------------------------------------------
void wifi_send_data(char data) {
 wifi_checkBusy();
 serverClient[0].print(data);
}



// --------------------------------------------------------
// sends clear screen codes to network terminal
// --------------------------------------------------------
void wifi_clrscr() {
  serverClient[0].print("\e[H\e[J");
}



// --------------------------------------------------------
// wait until a remote user connects 
// --------------------------------------------------------
void wifi_wait_for_connection() {

 // disconnect anything lingering
 wifi_disconnect_sessions();

 // polite loop that loops forever waiting...  
 while (server.hasClient() == 0) delay(100);
 
 // do we have a connect request?

 // we are available to service a client
 if (server.hasClient()) {
   serverClient[0] = server.available(); 
   Serial.println("\r\n*** Inbound WiFi-IP connection established ***\r\n\r\n");

   // set Telnet to full duplex, character mode
   serverClient[0].print(telnetOption1); // IAC DONT LINEMODE
   serverClient[0].print(telnetOption2); // IAC WILL ECHO
   serverClient[0].print(telnetOption3); // IAC WILL SUPPRESS GO AHEAD

   serverClient[0].print("\r\n\r\n");

   // absorb any initial data from remote telnet which is probably the
   // client negotiating the connection parameters
   wifi_clearBuffer();  
 }
 
} // end of wait_for_connection()



// --------------------------------------------------------
// start the wifi chip, connect to our router and 
// get ready to accept inbound connections
// --------------------------------------------------------
void initializeWiFi() {
 Serial.println("***********************************************");
 Serial.println("***    I n i t i a l i z i n g   W i F i    ***");
 Serial.println("***********************************************");
 Serial.println();

 if (want_wifi_scan == 1) WiFiScan();

 // put wifi chip into client mode
 WiFi.disconnect();
 WiFi.persistent(false);
 WiFi.mode(WIFI_OFF); 
 WiFi.mode(WIFI_STA);

 delay(1000); 

 // output our wifi ssid/password
 Serial.print("Trying SSID:");
 Serial.print(wifi_ssid);
 Serial.print("  PASS:");
 Serial.print(wifi_pass);

 // This will assign a STATIC IP to your ESP32
 #ifdef use_static_ip
 if (!WiFi.config(local_IP, gateway, subnet)) {
    Serial.println("*** Failed to configure static IP ***"); }
 #endif 
 
 WiFi.begin(wifi_ssid, wifi_pass);
  
 // wait upto 10 seconds for connection to occur
 uint8_t retryCount = 0;
 while ( (WiFi.status() != WL_CONNECTED) and (retryCount < 20) ) {
  Serial.print(".");
  retryCount++;
  delay(500);
 }

 // if we get here and we were unable to connect to our Wifi Network
 if (WiFi.status() != WL_CONNECTED) {
  Serial.println("\r\n!!! Unable to connect to WiFi Network !!!\r\nRestarting ESP Node...\r\n\r\n");
  delay(5000); // sleep for a few seconds
  Serial.end();
  ESP.restart(); // reset the CPU and retry everything again...
 }   

 // if we get here, the wifi has successfully connected
 Serial.print("\r\n\r\nConnected to Wifi using ");
 #ifdef use_static_ip
 Serial.println("a Static IP");
 #else
 Serial.println("DHCP");
 #endif
 
 Serial.print("IP Address: ");
 Serial.println(WiFi.localIP());

 // WiFi.printDiag(Serial);
 Serial.println("\r\n*** Waiting for inbound telnet session ***\n");

 // start listening on the WiFi IP
 server.begin();
 // server.setNoDelay(true);

 // now that our network is ready, wait for someone to connect...
 wifi_wait_for_connection();
  
}
