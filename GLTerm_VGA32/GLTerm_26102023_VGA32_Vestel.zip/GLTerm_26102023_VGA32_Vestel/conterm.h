// =========================================================================================
// Console abstraction functions
// =========================================================================================

#ifndef CONSOLE_H
#define CONSOLE_H

// =========================================================================================

typedef signed char     int8;
typedef signed short    int16;
typedef signed int      int32;
typedef unsigned char   uint8;
typedef unsigned short  uint16;
typedef unsigned int    uint32;

// =========================================================================================
// _kbhit
// =========================================================================================
int _kbhit(void)    {
                      return(Terminal.available()); 
                    }

// =========================================================================================
// _getch
// =========================================================================================
uint8 _getch(void)  {
                      while (!Terminal.available());
                      return(Terminal.read()); 
                    }

// =========================================================================================
// _getche
// =========================================================================================
uint8 _getche(void) {
                    uint8 ch = _getch();
                    Terminal.write(ch);
                    return(ch);
                    }

// =========================================================================================
// _putch
// =========================================================================================
void _putch(uint8 ch) {
                      Terminal.write(ch);
                      }

// =========================================================================================
// _clrscr
// =========================================================================================
void _clrscr(void)    {
                      Terminal.clear();
                      }

// =========================================================================================
// _esp_reboot
// =========================================================================================
void _esp_reboot(void) {
                        _clrscr();
                        ESP.restart();
                       }

// =========================================================================================
// uint8 mask8bit = 0x7f;    // this is the normal 7-Bit RunCPM-setting
              // To be used for masking 8 bit characters (XMODEM related)
              // If set to 0x7f, RunCPM masks the 8th bit of characters sent
              // to the console. This is the standard CP/M behavior.

// =========================================================================================
// using 8-bit Mode to control USBSerialFilter and also enable XMODEM
// =========================================================================================
uint8 mask8bit = 0xff;    // this is the 8-bit RunCPM-setting
							// If set to 0xff, RunCPM passes 8 bit characters. This is
							// required for XMODEM to work.
							// Use the CONSOLE7 and CONSOLE8 programs to change this on the fly.

// =========================================================================================
uint8 _chready(void)		// Checks if there's a character ready for input
                        {
                          return(_kbhit() ? 0xff : 0x00);
                        }

// =========================================================================================                        
uint8 _getchNB(void)		// Gets a character, non-blocking, no echo
                        {
                          return(_kbhit() ? _getch() : 0x00);
                        }

// =========================================================================================                        
void _putcon(uint8 ch)		// Puts a character
                        {
                          _putch(ch & mask8bit);
                        }

// =========================================================================================                        
void _puts(const char* str)	// Puts a \0 terminated string
                        {
                          while (*str)
                            _putcon(*(str++));
                        }

// =========================================================================================                        

#endif
