 /*
  Created by Fabrizio Di Vittorio (fdivitto2013@gmail.com) - www.fabgl.com
  Copyright (c) 2019-2020 Fabrizio Di Vittorio.
  All rights reserved.

  This file is part of FabGL Library.

  FabGL is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  FabGL is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with FabGL.  If not, see <http://www.gnu.org/licenses/>.
 */


#pragma once

#include <Preferences.h>

#include "fabui.h"
#include "uistyle.h"
#include "restartdialog.h"

Preferences preferences;


#define TERMVERSION_MAJ 1
#define TERMVERSION_MIN 4

static const char * BAUDRATES_STR[] = { "110", "300", "600", "1200", "2400", "4800", "9600", "14400", "19200", "38400", "57600", "115200", "128000", "230400", "250000", "256000", "500000", "1000000", "2000000" };
static const int    BAUDRATES_INT[] = { 110, 300, 600, 1200, 2400, 4800, 9600, 14400, 19200, 38400, 57600, 115200, 128000, 230400, 250000, 256000, 500000, 1000000, 2000000 };
constexpr int       BAUDRATES_COUNT = sizeof(BAUDRATES_INT) / sizeof(int);

static const char * DATALENS_STR[]  = { "5 bits", "6 bits", "7 bits", "8 bits" };
static const char * PARITY_STR[]    = { "None", "Even", "Odd" };
static const char * STOPBITS_STR[]  = { "1 bit", "1.5 bits", "2 bits" };
static const char * FLOWCTRL_STR[]  = { "None", "XON/XOFF", "RTS/CTS", "Combi" };

constexpr int       BOOTINFO_DISABLED     = 0;
constexpr int       BOOTINFO_ENABLED      = 1;
constexpr int       BOOTINFO_TEMPDISABLED = 2;

constexpr int       KEYCLICK_DISABLED     = 0;
constexpr int       KEYCLICK_ENABLED      = 1;

// preferences keys
static const char * PREF_VERMAJ         = "VerMaj";
static const char * PREF_VERMIN         = "VerMin";
static const char * PREF_TERMTYPE       = "TermType";
static const char * PREF_KBDLAYOUT      = "KbdLayout";
static const char * PREF_BAUDRATE       = "BaudRate";
static const char * PREF_DATALEN        = "DataLen";
static const char * PREF_PARITY         = "Parity";
static const char * PREF_STOPBITS       = "StopBits";
static const char * PREF_FLOWCTRL       = "FlowCtrl";
static const char * PREF_BGCOLOR        = "BGColor";
static const char * PREF_BDCOLOR        = "BDColor";
static const char * PREF_FGCOLOR        = "FGColor";
static const char * PREF_BOOTINFO       = "BootInfo";
static const char * PREF_KEYCLICK       = "KeyClick";


struct ConfDialogApp : public uiApp {

  Rect              frameRect;
  int               progToInstall;
  bool              lastCTSStatus;

  uiFrame *         frame;
  uiComboBox *      termComboBox;
  uiComboBox *      kbdComboBox;
  uiComboBox *      baudRateComboBox;
  uiComboBox *      datalenComboBox;
  uiComboBox *      parityComboBox;
  uiComboBox *      stopBitsComboBox;
  uiComboBox *      flowCtrlComboBox;  
  uiColorComboBox * bgColorComboBox;
  uiColorComboBox * fgColorComboBox;
  uiColorComboBox * bdColorComboBox;
  uiCheckBox *      infoCheckBox;
  uiCheckBox *      clickCheckBox;
  uiLabel *         RTSStatus;
  uiLabel *         CTSStatus;

  void init() {

    setStyle(&dialogStyle);

    rootWindow()->frameProps().fillBackground = false;

    frame = new uiFrame(rootWindow(), "Terminal Configuration", UIWINDOW_PARENTCENTER, Size(380, 275), true, STYLE_FRAME);
    frameRect = frame->rect(fabgl::uiOrigin::Screen);

    frame->frameProps().resizeable        = false;
    frame->frameProps().moveable          = false;
    frame->frameProps().hasCloseButton    = false;
    frame->frameProps().hasMaximizeButton = false;
    frame->frameProps().hasMinimizeButton = false;

    // ESC : exit without save
    // F10 : save and exit
    frame->onKeyUp = [&](uiKeyEventInfo key) {
      if (key.VK == VirtualKey::VK_ESCAPE)
        quit(0);
      if (key.VK == VirtualKey::VK_F10) {
        saveProps();
        quit(0);
      }
    };

    int y = 24;

    // little help
    new uiLabel(frame, "GLTerm for VGA32 by Guido Lehwalder", Point(100, y), Size(0, 0), true, STYLE_LABELHELP);
    new uiLabel(frame, "Press TAB key to move between fields", Point(100, y +18), Size(0, 0), true, STYLE_LABELHELP);

    y += 48;

    // select terminal emulation combobox
    new uiLabel(frame, "Terminal Type", Point(10,  y), Size(0, 0), true, STYLE_LABEL);
    termComboBox = new uiComboBox(frame, Point(10, y + 12), Size(85, 20), 80, true, STYLE_COMBOBOX);
    termComboBox->items().append(SupportedTerminals::names(), SupportedTerminals::count());
    termComboBox->selectItem((int)getTermType());

    // select keyboard layout
    new uiLabel(frame, "Keyboard Layout", Point(110, y), Size(0, 0), true, STYLE_LABEL);
    kbdComboBox = new uiComboBox(frame, Point(110, y + 12), Size(75, 20), 70, true, STYLE_COMBOBOX);
    kbdComboBox->items().append(SupportedLayouts::names(), SupportedLayouts::count());
    kbdComboBox->selectItem(getKbdLayoutIndex());

    // background color
    new uiLabel(frame, "Background Color", Point(200,  y), Size(0, 0), true, STYLE_LABEL);
    bgColorComboBox = new uiColorComboBox(frame, Point(200, y + 12), Size(75, 20), 70, true, STYLE_COMBOBOX);
    bgColorComboBox->selectColor(getBGColor());

    // foreground color
    new uiLabel(frame, "Foreground Color", Point(290,  y), Size(0, 0), true, STYLE_LABEL);
    fgColorComboBox = new uiColorComboBox(frame, Point(290, y + 12), Size(75, 20), 70, true, STYLE_COMBOBOX);
    fgColorComboBox->selectColor(getFGColor());

    y += 56;

    // show keyclick select
    new uiLabel(frame, "KeyClick", Point(10, y), Size(0, 0), true, STYLE_LABEL);
    clickCheckBox = new uiCheckBox(frame, Point(80, y - 2), Size(16, 16), uiCheckBoxKind::CheckBox, true, STYLE_CHECKBOX);
    clickCheckBox->setChecked(getKeyClick() == KEYCLICK_ENABLED);

    // bold attribute color
    new uiLabel(frame, "Bold Color", Point(290,  y-16), Size(0, 0), true, STYLE_LABEL);
    bdColorComboBox = new uiColorComboBox(frame, Point(290, y -4), Size(75, 20), 70, true, STYLE_COMBOBOX);
    bdColorComboBox->selectColor(getBDColor());

    
    y += 24;

    // show boot info
    new uiLabel(frame, "BootInfo", Point(10, y), Size(0, 0), true, STYLE_LABEL);
    infoCheckBox = new uiCheckBox(frame, Point(80, y - 2), Size(16, 16), uiCheckBoxKind::CheckBox, true, STYLE_CHECKBOX);
    infoCheckBox->setChecked(getBootInfo() == BOOTINFO_ENABLED);

    y += 24;

    // baud rate
    new uiLabel(frame, "Baud Rate", Point(10,  y), Size(0, 0), true, STYLE_LABEL);
    baudRateComboBox = new uiComboBox(frame, Point(10, y + 12), Size(70, 20), 70, true, STYLE_COMBOBOX);
    baudRateComboBox->items().append(BAUDRATES_STR, BAUDRATES_COUNT);
    baudRateComboBox->selectItem(getBaudRateIndex());

    // data length
    new uiLabel(frame, "Data Length", Point(95,  y), Size(0, 0), true, STYLE_LABEL);
    datalenComboBox = new uiComboBox(frame, Point(95, y + 12), Size(60, 20), 70, true, STYLE_COMBOBOX);
    datalenComboBox->items().append(DATALENS_STR, 4);
    datalenComboBox->selectItem(getDataLenIndex());

    // parity
    new uiLabel(frame, "Parity", Point(170,  y), Size(0, 0), true, STYLE_LABEL);
    parityComboBox = new uiComboBox(frame, Point(170, y + 12), Size(45, 20), 50, true, STYLE_COMBOBOX);
    parityComboBox->items().append(PARITY_STR, 3);
    parityComboBox->selectItem(getParityIndex());

    // stop bits
    new uiLabel(frame, "Stop Bits", Point(230,  y), Size(0, 0), true, STYLE_LABEL);
    stopBitsComboBox = new uiComboBox(frame, Point(230, y + 12), Size(55, 20), 50, true, STYLE_COMBOBOX);
    stopBitsComboBox->items().append(STOPBITS_STR, 3);
    stopBitsComboBox->selectItem(getStopBitsIndex() - 1);

    // flow control
    new uiLabel(frame, "Flow Control", Point(300,  y), Size(0, 0), true, STYLE_LABEL);
    flowCtrlComboBox = new uiComboBox(frame, Point(300, y + 12), Size(65, 20), 35, true, STYLE_COMBOBOX);
    flowCtrlComboBox->items().append(FLOWCTRL_STR, 4);
    flowCtrlComboBox->selectItem((int)getFlowCtrl());

    y += 48;

    // Quit button: exit without save
    auto exitNoSaveButton = new uiButton(frame, "Quit [ESC]", Point(10, y), Size(58, 20), uiButtonKind::Button, true, STYLE_BUTTON);
    exitNoSaveButton->onClick = [&]() {
      quit(0);
    };

    // Save & Quit button: exit with save
    auto exitSaveButton = new uiButton(frame, "Save & Quit [F10]", Point(74, y), Size(90, 20), uiButtonKind::Button, true, STYLE_BUTTON);
    exitSaveButton->onClick = [&]() {
      saveProps();
      quit(0);
    };


    // RTS Status (clickable)
    RTSStatus = new uiLabel(frame, "RTS", Point(300, 210), Size(30, 15), true, STYLE_LABELBUTTON);
    setRTSStatus(Terminal.RTSStatus());
    RTSStatus->onClick = [&]() {
      bool newval = !Terminal.RTSStatus();
      Terminal.setRTSStatus(newval);
      setRTSStatus(newval);
    };

    // CTS Status
    CTSStatus = new uiLabel(frame, "CTS", Point(335, 210), Size(30, 15), true, STYLE_LABELBUTTON);
    lastCTSStatus = Terminal.CTSStatus();
    setCTSStatus(lastCTSStatus);

    // timer
    frame->onTimer = [&](uiTimerHandle) {
      // monitor CTS status
      if (Terminal.CTSStatus() != lastCTSStatus) {
        lastCTSStatus = !lastCTSStatus;
        setCTSStatus(lastCTSStatus);
      }
    };
    setTimer(frame, 100);


    setActiveWindow(frame);
    setFocusedWindow(exitNoSaveButton);

  }


  void setRTSStatus(bool status) {
    RTSStatus->labelStyle().backgroundColor = status ? RGB888(0, 128, 0) : RGB888(128, 128, 128);
    RTSStatus->repaint();
  }


  void setCTSStatus(bool status) {
    CTSStatus->labelStyle().backgroundColor = status ? RGB888(128, 0, 0) : RGB888(128, 128, 128);
    CTSStatus->repaint();
  }

  void saveProps() {

    // need reboot?
    bool reboot =    infoCheckBox->checked()  != getBootInfo() ||
                    clickCheckBox->checked()  != getKeyClick();
                  
    preferences.putInt(PREF_TERMTYPE, termComboBox->selectedItem());
    preferences.putInt(PREF_KBDLAYOUT, kbdComboBox->selectedItem());
    preferences.putInt(PREF_BAUDRATE, baudRateComboBox->selectedItem());
    preferences.putInt(PREF_DATALEN, datalenComboBox->selectedItem());
    preferences.putInt(PREF_PARITY, parityComboBox->selectedItem());
    preferences.putInt(PREF_STOPBITS, stopBitsComboBox->selectedItem() + 1);
    preferences.putInt(PREF_FLOWCTRL, flowCtrlComboBox->selectedItem());    
    preferences.putInt(PREF_BGCOLOR, (int)bgColorComboBox->selectedColor());
    preferences.putInt(PREF_FGCOLOR, (int)fgColorComboBox->selectedColor());
    preferences.putInt(PREF_BDCOLOR, (int)bdColorComboBox->selectedColor());
    preferences.putInt(PREF_BOOTINFO, infoCheckBox->checked() ? BOOTINFO_ENABLED : BOOTINFO_DISABLED);
    preferences.putInt(PREF_KEYCLICK, clickCheckBox->checked() ? KEYCLICK_ENABLED : KEYCLICK_DISABLED);
    
    if (reboot) {
      auto rebootDialog = new RebootDialog(frame);
      showModalWindow(rebootDialog);  // no return!
    }

    loadConfiguration();
  }


  ~ConfDialogApp() {
    // this is required, becasue the terminal may not cover the entire screen
    canvas()->reset();
    canvas()->setBrushColor(getBGColor());
    canvas()->fillRectangle(frameRect);
  }


  static TermType getTermType() {
    return (TermType) preferences.getInt(PREF_TERMTYPE, 7);    // default 7 = ANSILegacy
  }


  static int getKbdLayoutIndex() {
    return preferences.getInt(PREF_KBDLAYOUT, 3);              // default 3 = "US"
  }


  static int getBaudRateIndex() {
    return preferences.getInt(PREF_BAUDRATE, 11);              // default 11 = 115200
  }


  static int getDataLenIndex() {
    return preferences.getInt(PREF_DATALEN, 3);                // default 3 = 8 bits
  }


  static int getParityIndex() {
    return preferences.getInt(PREF_PARITY, 0);                 // default 0 = no parity
  }


  static int getStopBitsIndex() {
    return preferences.getInt(PREF_STOPBITS, 1);               // default 1 = 1 stop bit
  }


  static FlowControl getFlowCtrl() {
    return (FlowControl) preferences.getInt(PREF_FLOWCTRL, 0); // default 0 = no flow control
  }


  static Color getBGColor() {
    return (Color) preferences.getInt(PREF_BGCOLOR, (int)Color::Black);
  }


  static Color getFGColor() {
    return (Color) preferences.getInt(PREF_FGCOLOR, (int)Color::BrightGreen);
  }

  static Color getBDColor() {
    return (Color) preferences.getInt(PREF_BDCOLOR, (int)Color::BrightYellow);
  }

  static int getBootInfo() {
    return preferences.getInt(PREF_BOOTINFO, BOOTINFO_ENABLED);
  }

  static int getKeyClick() {
    return preferences.getInt(PREF_KEYCLICK, KEYCLICK_ENABLED);
  }


  // if version in preferences doesn't match, reset preferences
  static void checkVersion() {
    if (preferences.getInt("VerMaj", 0) != TERMVERSION_MAJ || preferences.getInt("VerMin", 0) != TERMVERSION_MIN) {
      preferences.clear();
      preferences.putInt("VerMaj", TERMVERSION_MAJ);
      preferences.putInt("VerMin", TERMVERSION_MIN);
    }
  }


  static void loadConfiguration() {
    
    Terminal.setTerminalType(getTermType());
    Terminal.keyboard()->setLayout(SupportedLayouts::layouts()[getKbdLayoutIndex()]);
    // Terminal.connectLocally();                  // to use Terminal.read(), available(), etc..
    Terminal.setBackgroundColor(getBGColor());
    Terminal.setForegroundColor(getFGColor());
    // change the bold color but dont (false) apply the blurry/unsharp maintainStyle
    Terminal.setColorForAttribute(CharStyle::Bold, getBDColor(), false);

    // configure serial port
    // bool serctl = (getSerCtl() == SERCTL_ENABLED);
    // auto rxPin = serctl ? UART_URX : UART_SRX;
    // auto txPin = serctl ? UART_UTX : UART_STX;
    // Terminal.connectSerialPort(BAUDRATES_INT[getBaudRateIndex()], fabgl::UARTConf(getParityIndex(), getDataLenIndex(), getStopBitsIndex()), rxPin, txPin, getFlowCtrl(), false, RTS, CTS);

    // Example
    // Terminal.begin(&DisplayController);
    // Terminal.connectSerialPort(115200, SERIAL_8N1, 34, 2, FlowControl::Software);

    // configure serial port
    // Terminal.connectSerialPort(115200, SERIAL_8N1, UART_SRX, UART_STX, 0, false, RTS, CTS);
    // Terminal.connectSerialPort(115200, SERIAL_8N1, UART_SRX, UART_STX, FlowControl::None);
    // Terminal.connectSerialPort(BAUDRATES_INT[getBaudRateIndex()], fabgl::UARTConf(getParityIndex(), getDataLenIndex(), getStopBitsIndex()), UART_SRX, UART_STX, getFlowCtrl());
    Terminal.connectSerialPort(BAUDRATES_INT[getBaudRateIndex()], fabgl::UARTConf(getParityIndex(), getDataLenIndex(), getStopBitsIndex()), UART_SRX, UART_STX, getFlowCtrl(), false, RTS, CTS); 
  }

};
