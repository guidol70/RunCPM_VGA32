#ifndef HOST_H
#define HOST_H

uint8 hostbdos(uint16 dmaaddr) {
	return(0x00);
}

#endif